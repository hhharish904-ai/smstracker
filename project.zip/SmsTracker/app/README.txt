SETUP
1. Android Studio > New Project > "Empty Views Activity" (Kotlin), package com.example.smstracker, min SDK 24.
2. Replace AndroidManifest.xml with the one here.
3. Put MainActivity.kt and SmsParser.kt in app/src/main/java/com/example/smstracker/ (overwrite).
4. Run on a real phone (emulators have no bank SMS). Allow the SMS permission.

NOTES
- Everything is parsed on-device; nothing is uploaded.
- Regexes target common Indian bank formats (Rs/INR/₹, "Avl Bal", "Total Amt Due"). Tweak SmsParser.kt for your bank's wording.
- Google Play restricts READ_SMS, so this is for personal/sideloaded use.
