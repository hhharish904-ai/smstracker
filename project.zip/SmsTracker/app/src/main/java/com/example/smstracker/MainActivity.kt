package com.example.smstracker

import android.Manifest
import android.app.Activity
import android.content.pm.PackageManager
import android.os.Bundle
import android.provider.Telephony
import android.widget.ArrayAdapter
import android.widget.ListView
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (checkSelfPermission(Manifest.permission.READ_SMS) == PackageManager.PERMISSION_GRANTED) load()
        else requestPermissions(arrayOf(Manifest.permission.READ_SMS), 1)
    }

    override fun onRequestPermissionsResult(code: Int, p: Array<out String>, r: IntArray) {
        if (r.isNotEmpty() && r[0] == PackageManager.PERMISSION_GRANTED) load()
        else setContentView(TextView(this).apply { text = "SMS permission is needed to read account messages."; setPadding(40, 40, 40, 40) })
    }

    private fun load() {
        val msgs = mutableListOf<Sms>()
        contentResolver.query(
            Telephony.Sms.Inbox.CONTENT_URI,
            arrayOf(Telephony.Sms.ADDRESS, Telephony.Sms.BODY, Telephony.Sms.DATE),
            null, null, "date DESC"
        )?.use { c ->
            while (c.moveToNext() && msgs.size < 3000)
                msgs.add(Sms(c.getString(0) ?: "", c.getString(1) ?: "", c.getLong(2)))
        }
        val accounts = SmsParser.summarize(msgs)
        val list = ListView(this)
        list.adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1,
            if (accounts.isEmpty()) listOf("No bank or card messages found.") else accounts.map { it.display() })
        setContentView(list)
    }
}
