package com.example.smstracker

data class Sms(val sender: String, val body: String, val date: Long)

data class Account(
    val sender: String,
    val last4: String,
    var balance: String? = null,
    var balanceDate: Long = 0,
    var dueAmount: String? = null,
    var dueDate: String? = null,
    var lastTxn: String? = null
) {
    fun display(): String = buildString {
        append("$sender  •••$last4\n")
        append("Balance: ${balance ?: "–"}\n")
        if (dueAmount != null || dueDate != null)
            append("Bill due: ${dueAmount ?: "–"} by ${dueDate ?: "–"}\n")
        if (lastTxn != null) append("Last: $lastTxn")
    }.trim()
}

object SmsParser {
    private val money = "(?:rs\\.?|inr|₹)\\s*([\\d,]+(?:\\.\\d{1,2})?)"
    private val acct = Regex("(?i)(?:a/c|acct|account|card)[^\\d]{0,12}(\\d{3,4})")
    private val balance = Regex("(?i)(?:avl|avail(?:able)?|total)?\\.?\\s*bal(?:ance)?[^\\d]{0,15}$money")
    private val txn = Regex("(?i)$money[^.]{0,40}?(debited|spent|withdrawn|credited|received)|(debited|credited)[^\\d]{0,20}$money")
    private val dueAmt = Regex("(?i)(?:total\\s*(?:amt|amount)\\s*due|amount\\s*due|min(?:imum)?\\s*(?:amt|amount)?\\s*due)[^\\d]{0,15}$money")
    private val dueDate = Regex("(?i)(?:due\\s*(?:date|on|by)?|pay\\s*by)[^\\d]{0,10}(\\d{1,2}[-/ ](?:\\d{1,2}|[a-z]{3,9})[-/ ]\\d{2,4})")

    /** Messages must be newest-first. Keeps the latest info per account. */
    fun summarize(msgs: List<Sms>): List<Account> {
        val map = LinkedHashMap<String, Account>()
        for (m in msgs) {
            val a = acct.find(m.body)?.groupValues?.get(1) ?: continue
            val acc = map.getOrPut("${m.sender}-$a") { Account(m.sender, a) }
            if (acc.balance == null) balance.find(m.body)?.let {
                acc.balance = "₹" + it.groupValues[1]; acc.balanceDate = m.date
            }
            if (acc.dueAmount == null) dueAmt.find(m.body)?.let { acc.dueAmount = "₹" + it.groupValues[1] }
            if (acc.dueDate == null) dueDate.find(m.body)?.let { acc.dueDate = it.groupValues[1] }
            if (acc.lastTxn == null) txn.find(m.body)?.let { acc.lastTxn = it.value.take(60) }
        }
        return map.values.filter { it.balance != null || it.dueDate != null }
    }
}
